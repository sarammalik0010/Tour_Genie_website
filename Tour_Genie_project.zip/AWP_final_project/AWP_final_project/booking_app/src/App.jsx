// src/App.jsx
import { Outlet, useLocation } from 'react-router-dom';
import Navbar1 from './components/Navbar/Navbar1';
import Footer from './components/Footer/Footer';

function App() {
  const location = useLocation();

  // DEBUG
  console.log('current path:', location.pathname);

  // Hide navbar on these exact paths:
  const hideNavbar = [
    '/',              // if you want to hide on home/landing
    '/login',
    '/signup',
    '/landingpage'    // or whatever your landing route is
  ].includes(location.pathname);

  return (
    <>
      {!hideNavbar && <Navbar1 />}
      <Outlet />
      <Footer />
    </>
  );
}

export default App;
