import React, { useState, useEffect } from 'react';
import axios from 'axios';

const Recommendations = () => {
  const [countries, setCountries] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // You can replace this list with any country names you want
    const countryList = ['pakistan', 'turkey', 'japan', 'malaysia', 'france'];

    Promise.all(
      countryList.map(name =>
        axios.get(`https://restcountries.com/v3.1/name/${name}`).then(res => res.data[0])
      )
    )
      .then(results => {
        setCountries(results);
        setLoading(false);
      })
      .catch(err => {
        console.error('Error fetching countries:', err);
        setLoading(false);
      });
  }, []);

  if (loading) return <p className="text-center mt-10 text-gray-600">Loading recommendations...</p>;
  if (!countries.length) return <p className="text-center text-red-500 mt-10">Failed to load data.</p>;

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-white py-12 px-4 sm:px-8">
      <h1 className="text-4xl font-extrabold text-blue-700 text-center mb-10 tracking-tight">
        🌍 Top Travel Recommendations
      </h1>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8 max-w-7xl mx-auto">
        {countries.map((country, i) => (
          <div key={i} className="bg-white p-6 rounded-xl shadow-md border hover:shadow-lg transition">
            <h2 className="text-2xl font-semibold text-blue-700 mb-2">{country.name.common}</h2>
            <img
              src={country.flags.svg}
              alt={`${country.name.common} flag`}
              className="w-full h-32 object-cover rounded-md mb-4 border"
            />
            <div className="space-y-1 text-sm text-gray-700">
              <p><strong>📍 Region:</strong> {country.region}</p>
              <p><strong>👥 Population:</strong> {country.population.toLocaleString()}</p>
              <p><strong>🏛️ Capital:</strong> {country.capital?.[0] || 'N/A'}</p>
              <p><strong>🗣️ Languages:</strong> {country.languages ? Object.values(country.languages).join(', ') : 'N/A'}</p>
              <p><strong>🌐 Subregion:</strong> {country.subregion || 'N/A'}</p>
              <p><strong>🌎 Continents:</strong> {country.continents?.join(', ') || 'N/A'}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Recommendations;
