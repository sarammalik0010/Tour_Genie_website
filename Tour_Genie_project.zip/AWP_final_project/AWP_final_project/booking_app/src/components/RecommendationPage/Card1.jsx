// src/components/Card.jsx
import React from 'react';

const Card = ({ title, type, description, image }) => {
  return (
    <div className="bg-white border border-blue-100 rounded-xl overflow-hidden shadow-lg hover:shadow-2xl transform hover:scale-105 transition-all duration-500 group">
      {/* Image Section */}
      {image ? (
        <img
          src={image}
          alt={title}
          className="w-full h-56 object-cover"
        />
      ) : (
        <div className="w-full h-56 flex items-center justify-center bg-gradient-to-tr from-blue-100 to-blue-200 text-gray-400 text-sm">
          Image Placeholder
        </div>
      )}

      {/* Text Content */}
      <div className="p-6 space-y-3">
        <h2 className="text-xl font-bold text-gray-800 group-hover:text-blue-700 transition-colors duration-300">
          {title} <span className="text-sm text-blue-600">({type})</span>
        </h2>
        <p className="text-gray-600">{description}</p>
      </div>
    </div>
  );
};

export default Card;