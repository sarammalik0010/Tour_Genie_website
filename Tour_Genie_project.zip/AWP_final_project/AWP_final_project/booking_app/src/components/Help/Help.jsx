import React, { useState } from 'react';

const faqs = [
  {
    question: "How do I book a trip with Tour Genie?",
    answer: "Navigate to the 'Booking' tab, choose your destination and dates, and proceed with the payment process.",
  },
  {
    question: "Can I edit my itinerary after booking?",
    answer: "Yes, you can update your itinerary anytime from the 'Itinerary' section in your dashboard.",
  },
  {
    question: "Is there a mobile app available?",
    answer: "Currently, Tour Genie is available as a web app. Mobile app is under development.",
  },
  {
    question: "How can I contact customer support?",
    answer: "You can reach out to us through the 'Contact' section or email support@tourgenie.com.",
  },
  {
    question: "How do I reset my password?",
    answer: "Go to 'Settings' > 'Change Password' to reset your password securely.",
  },
];

const Help = () => {
  const [openIndex, setOpenIndex] = useState(null);

  const toggle = (index) => {
    setOpenIndex(openIndex === index ? null : index);
  };

  return (
    <div className="min-h-screen bg-blue-50 py-10 px-4">
      <div className="max-w-4xl mx-auto bg-white shadow-md rounded-lg p-8">
        <h1 className="text-3xl font-bold text-center text-blue-700 mb-6">
          🙋 Help Center & FAQ
        </h1>
        <p className="text-center text-gray-500 mb-8">
          Find answers to common questions or contact support for further help.
        </p>

        {/* FAQs */}
        <div className="space-y-4">
          {faqs.map((item, index) => (
            <div key={index} className="border rounded-lg overflow-hidden">
              <button
                onClick={() => toggle(index)}
                className="w-full text-left px-4 py-3 bg-blue-100 hover:bg-blue-200 text-blue-700 font-medium focus:outline-none flex justify-between items-center"
              >
                <span>{item.question}</span>
                <span>{openIndex === index ? '-' : '+'}</span>
              </button>
              {openIndex === index && (
                <div className="px-4 py-3 text-gray-600 bg-white transition">
                  {item.answer}
                </div>
              )}
            </div>
          ))}
        </div>

        {/* Contact Support */}
        <div className="mt-10 text-center">
          <h2 className="text-xl font-semibold text-blue-600 mb-2">Still need help?</h2>
          <p className="text-gray-600 mb-4">
            Contact our support team for personalized assistance.
          </p>
          <a
            href="mailto:support@tourgenie.com"
            className="inline-block bg-blue-600 text-white px-6 py-2 rounded-md hover:bg-blue-700 transition"
          >
            Contact Support
          </a>
        </div>
      </div>
    </div>
  );
};

export default Help;
