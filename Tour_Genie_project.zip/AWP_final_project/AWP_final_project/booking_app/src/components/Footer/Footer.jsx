import React from 'react';

const Footer = () => {
  return (
    <footer className="bg-gradient-to-r from-sky-100 via-blue-200 to-sky-100 py-8 mt-16 rounded-t-3xl shadow-lg border-t border-blue-300 transition-all duration-300">
      <div className="max-w-7xl mx-auto px-6 flex flex-col sm:flex-row justify-between items-center">
        {/* Logo / Brand */}
        <div className="text-center sm:text-left mb-4 sm:mb-0">
          <h1 className="text-2xl font-bold text-blue-700">Tour Genie</h1>
          <p className="text-sm text-gray-600 mt-1">Explore the world with confidence</p>
        </div>

        {/* Navigation Links */}
        <div className="flex flex-wrap gap-4 justify-center sm:justify-start text-sm font-medium">
          <a href="#" className="text-gray-700 hover:text-blue-600 hover:underline transition duration-200">Privacy Policy</a>
          <a href="#" className="text-gray-700 hover:text-blue-600 hover:underline transition duration-200">Terms of Service</a>
          <a href="#" className="text-gray-700 hover:text-blue-600 hover:underline transition duration-200">Contact</a>
        </div>

        {/* Social Icons */}
        <div className="flex space-x-4 mt-4 sm:mt-0">
          <a href="#" className="text-blue-600 hover:text-white bg-white hover:bg-blue-600 p-2 rounded-full transition duration-300 shadow-md">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="currentColor" viewBox="0 0 24 24">
              <path d="M22 5.72c-.77.35-1.6.58-2.46.69a4.26 4.26 0 0 0 1.87-2.35c-.82.49-1.72.84-2.69 1.03a4.23 4.23 0 0 0-7.21 3.86c-3.52-.17-6.64-1.86-8.73-4.42a4.25 4.25 0 0 0 1.31 5.65 4.2 4.2 0 0 1-1.91-.53v.05a4.24 4.24 0 0 0 3.39 4.15c-.45.12-.93.18-1.41.18-.34 0-.68-.03-1-.09a4.25 4.25 0 0 0 3.96 2.94A8.5 8.5 0 0 1 2 19.55a11.99 11.99 0 0 0 6.29 1.84c7.55 0 11.68-6.26 11.68-11.69 0-.18 0-.35-.01-.52A8.34 8.34 0 0 0 22 5.72z" />
            </svg>
          </a>
          <a href="#" className="text-blue-600 hover:text-white bg-white hover:bg-blue-600 p-2 rounded-full transition duration-300 shadow-md">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="currentColor" viewBox="0 0 24 24">
              <path d="M21 21H3V3h9v2H5v14h14v-7h2v9zm-3.7-14c.42 0 .76.15 1.03.45.26.3.4.67.4 1.11 0 .42-.14.78-.42 1.09-.28.31-.63.47-1.06.47s-.79-.16-1.07-.47c-.28-.31-.42-.67-.42-1.09 0-.43.14-.8.42-1.11.28-.3.64-.45 1.12-.45zM9 19V9h2v1.5c.46-.66 1.02-1.09 1.68-1.29.63-.19 1.3-.21 2.01-.04.69.17 1.22.57 1.6 1.2.37.62.56 1.48.56 2.58V19h-2v-5.6c0-.8-.13-1.36-.39-1.67-.26-.31-.6-.46-1.03-.46s-.78.15-1.04.45c-.26.3-.39.83-.39 1.58V19H9z" />
            </svg>
          </a>
          <a href="#" className="text-blue-600 hover:text-white bg-white hover:bg-blue-600 p-2 rounded-full transition duration-300 shadow-md">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="currentColor" viewBox="0 0 24 24">
              <path d="M12 2.04c-5.51 0-9.96 4.45-9.96 9.96 0 4.41 2.87 8.15 6.85 9.49.5.09.68-.21.68-.47v-1.7c-2.79.61-3.37-1.34-3.37-1.34-.45-1.15-1.11-1.45-1.11-1.45-.9-.62.07-.61.07-.61 1 .07 1.53 1.04 1.53 1.04.89 1.53 2.34 1.09 2.91.83.09-.65.35-1.09.64-1.34-2.23-.26-4.56-1.11-4.56-4.95 0-1.1.39-2 .1-2.7 0 0 .84-.27 2.75 1.02.8-.22 1.66-.33 2.52-.33s1.72.11 2.52.33c1.91-1.29 2.75-1.02 2.75-1.02.29.7.1 1.6.05 2.7 0 3.86-2.33 4.69-4.56 4.95.36.31.68.92.68 1.85v2.74c0 .27.18.57.69.47a10.02 10.02 0 0 0 6.85-9.49c0-5.51-4.45-9.96-9.96-9.96z" />
            </svg>
          </a>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
