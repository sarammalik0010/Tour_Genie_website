import React, { useState } from "react";

const BudgetPlanner = () => {
  const [budget, setBudget] = useState(0);
  const [expenseName, setExpenseName] = useState("");
  const [expenseAmount, setExpenseAmount] = useState("");
  const [expenseCategory, setExpenseCategory] = useState("General");
  const [expenses, setExpenses] = useState([]);

  const handleAddExpense = () => {
    if (!expenseName || !expenseAmount || !expenseCategory) return;

    const newExpense = {
      name: expenseName,
      amount: parseFloat(expenseAmount),
      category: expenseCategory,
    };

    setExpenses([...expenses, newExpense]);
    setExpenseName("");
    setExpenseAmount("");
    setExpenseCategory("General");
  };

  const totalSpent = expenses.reduce((total, item) => total + item.amount, 0);
  const remaining = budget - totalSpent;

  return (
    <div className="max-w-5xl mx-auto p-6 mt-10 bg-white shadow-xl rounded-lg border border-blue-100">
      <h2 className="text-3xl font-bold text-blue-600 mb-6 text-center">🎯 Budget Planner</h2>

      {/* Budget Summary */}
      <div className="grid sm:grid-cols-2 gap-4 mb-8">
        <div>
          <label className="block text-sm font-semibold text-gray-700">Set Total Budget</label>
          <input
            type="number"
            className="w-full mt-2 p-2 border border-gray-300 rounded-md focus:ring focus:ring-blue-200"
            value={budget}
            onChange={(e) => setBudget(Number(e.target.value))}
            placeholder="e.g., 10000"
          />
        </div>

        <div className="bg-blue-50 border border-blue-200 p-4 rounded-lg text-center shadow-sm">
          <p className="text-gray-600 font-medium">Remaining Budget</p>
          <p className={`text-2xl font-bold transition duration-300 ${remaining < 0 ? "text-red-600" : "text-green-600"}`}>
            Rs {remaining}
          </p>
        </div>
      </div>

      {/* Add Expense Section */}
      <div className="grid sm:grid-cols-3 gap-4 mb-8">
        <input
          type="text"
          placeholder="Expense Name"
          className="p-2 border border-gray-300 rounded-md focus:ring focus:ring-blue-200"
          value={expenseName}
          onChange={(e) => setExpenseName(e.target.value)}
        />

        <input
          type="number"
          placeholder="Amount (Rs)"
          className="p-2 border border-gray-300 rounded-md focus:ring focus:ring-blue-200"
          value={expenseAmount}
          onChange={(e) => setExpenseAmount(e.target.value)}
        />

        <select
          className="p-2 border border-gray-300 rounded-md focus:ring focus:ring-blue-200"
          value={expenseCategory}
          onChange={(e) => setExpenseCategory(e.target.value)}
        >
          <option>General</option>
          <option>Accommodation</option>
          <option>Transport</option>
          <option>Food</option>
          <option>Activities</option>
          <option>Shopping</option>
          <option>Emergency</option>
        </select>

        <button
          onClick={handleAddExpense}
          className="sm:col-span-3 bg-blue-600 text-white font-semibold py-2 rounded-md mt-2 hover:bg-blue-700 transition duration-300"
        >
          ➕ Add Expense
        </button>
      </div>

      {/* Expense List */}
      <div>
        <h3 className="text-lg font-semibold text-gray-700 mb-4">🧾 Expense Breakdown</h3>
        {expenses.length === 0 ? (
          <p className="text-gray-500 italic">No expenses added yet.</p>
        ) : (
          <ul className="space-y-3">
            {expenses.map((expense, index) => (
              <li
                key={index}
                className="flex justify-between items-center p-3 bg-gray-50 border border-gray-200 rounded-md hover:shadow transition"
              >
                <div>
                  <p className="font-medium text-gray-800">{expense.name}</p>
                  <span className="text-sm text-gray-500">{expense.category}</span>
                </div>
                <span className="text-red-600 font-semibold">- Rs {expense.amount}</span>
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
};

export default BudgetPlanner;
