import React, { useState } from 'react';

const Itinerary = () => {
  const [itinerary, setItinerary] = useState([]);
  const [day, setDay] = useState('');
  const [activity, setActivity] = useState('');

  const addDay = () => {
    if (!day.trim()) return;
    setItinerary([...itinerary, { day, activities: [] }]);
    setDay('');
  };

  const addActivity = (index) => {
    if (!activity.trim()) return;
    const updated = [...itinerary];
    updated[index].activities.push(activity);
    setItinerary(updated);
    setActivity('');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-white p-8">
      <div className="max-w-4xl mx-auto bg-white shadow-lg rounded-lg p-6 animate-fade-in">
        <h1 className="text-4xl font-bold text-blue-700 mb-6 text-center">🧭 Itinerary Planner</h1>

        {/* Add Day Input */}
        <div className="flex flex-col sm:flex-row gap-4 mb-6 items-center">
          <input
            type="text"
            value={day}
            onChange={(e) => setDay(e.target.value)}
            placeholder="✏️ Enter Day (e.g. Day 1, Monday)"
            className="flex-1 border border-blue-300 p-3 rounded shadow-sm focus:outline-none focus:ring focus:ring-blue-200"
          />
          <button
            onClick={addDay}
            className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 rounded transition duration-300"
          >
            ➕ Add Day
          </button>
        </div>

        {/* Display Itinerary Days */}
        {itinerary.map((item, index) => (
          <div
            key={index}
            className="bg-gray-50 border border-gray-200 rounded-lg p-5 mb-6 shadow-md animate-fade-slide"
          >
            <h2 className="text-2xl font-semibold text-gray-800 mb-3">
              📅 {item.day}
            </h2>

            <ul className="list-disc list-inside text-gray-700 mb-4">
              {item.activities.map((act, i) => (
                <li key={i} className="mb-1">🎯 {act}</li>
              ))}
            </ul>

            {/* Add Activity */}
            <div className="flex flex-col sm:flex-row gap-3 mt-4">
              <input
                type="text"
                value={activity}
                onChange={(e) => setActivity(e.target.value)}
                placeholder="🏖️ Add activity"
                className="flex-1 border border-green-300 p-2 rounded shadow-sm focus:outline-none focus:ring focus:ring-green-200"
              />
              <button
                onClick={() => addActivity(index)}
                className="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded transition duration-300"
              >
                ➕ Add Activity
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Itinerary;
