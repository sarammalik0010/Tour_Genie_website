import React, { useState,useEffect } from 'react';
import { MapPin, Star, Bell, Calendar, User, Heart,  MessageCircle,  Search, Bookmark, Camera, Globe } from 'lucide-react';
import { Link } from 'react-router-dom';
import axios from 'axios'
import Navbar from '../Landingpage/Navbar';
import Navbar1 from '../Navbar/Navbar1';
const Dashboard = () => {
  const [notifications, setNotifications] = useState([
    { id: 1, type: 'reminder', message: 'Your Hunza Valley trip is tomorrow! Check your itinerary.', time: '2 hours ago', read: false },
    { id: 2, type: 'offer', message: 'Special 20% off on Swat jeep tours – Limited time!', time: '1 day ago', read: false },
    { id: 3, type: 'update', message: 'Weather update for your Skardu adventure next week', time: '2 days ago', read: true }
  ]);
  const [user, setUser] = useState(null);
useEffect(() => {
  const fetchUser = async () => {
    try {
      const token = localStorage.getItem('token');
      const response = await axios.get('http://localhost:3000/users/profile', {
        headers: { Authorization: `Bearer ${token}` }
      });
      console.log("Fetched user:", response.data); // 👈 add this line
      setUser(response.data);
    } catch (error) {
      console.error('Failed to fetch user profile:', error);
    }
  };
  fetchUser();
}, []);


  const upcomingTrips = [
    {
      id: 1,
      title: "Full-Day Hunza Valley Cultural Tour",
      date: "Tomorrow, Jun 30",
      time: "9:00 AM",
      location: "Hunza, Pakistan",
      image: "https://images.unsplash.com/photo-1523906834658-6e24ef2386f9?w=300&h=200&fit=crop",
      status: "confirmed",
      participants: 3,
      guide: "Ali R."
    },
    {
      id: 2,
      title: "Swat Valley Jeep Safari Experience",
      date: "Jul 5, 2025",
      time: "11:00 AM",
      location: "Swat, Pakistan",
      image: "https://images.unsplash.com/photo-1506377585622-bedcbb027afc?w=300&h=200&fit=crop",
      status: "pending",
      participants: 5,
      guide: "Farah K."
    }
  ];

  const recommendations = [
    {
      id: 1,
      title: "Lahore Walled City Heritage Tour",
      image: "https://images.unsplash.com/photo-1552832230-c0197dd311b5?w=300&h=200&fit=crop",
      rating: 4.8,
      reviews: 412,
      price: "PKR 2,000",
      duration: "2 hours",
      reason: "Based on your love for cultural tours"
    },
    {
      id: 2,
      title: "Neelum Valley Nature Photography Tour",
      image: "https://images.unsplash.com/photo-1523906921802-b5d2d899e93b?w=300&h=200&fit=crop",
      rating: 4.7,
      reviews: 325,
      price: "PKR 4,500",
      duration: "6 hours",
      reason: "Popular among nature lovers"
    },
    {
      id: 3,
      title: "Skardu Trekking Adventure",
      image: "https://images.unsplash.com/photo-1516483638261-f4dbaf036963?w=300&h=200&fit=crop",
      rating: 4.9,
      reviews: 198,
      price: "PKR 7,000",
      duration: "Full day",
      reason: "Perfect for your next hiking trip"
    }
  ];

  const recentActivity = [
    { id: 1, action: "Booked", item: "Hunza Valley Tour", time: "3 days ago", icon: Calendar },
    { id: 2, action: "Saved", item: "Skardu Adventure", time: "1 week ago", icon: Heart },
    { id: 3, action: "Reviewed", item: "Lahore Food Walk", time: "2 weeks ago", icon: Star },
    { id: 4, action: "Shared", item: "Swat Jeep Safari", time: "3 weeks ago", icon: MessageCircle }
  ];

  const markNotificationRead = (id) => {
    setNotifications(notifications.map(notif =>
      notif.id === id ? { ...notif, read: true } : notif
    ));
  };

  return (
   
        <div className="min-h-screen bg-gray-50">
         
    


      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">
            Welcome back, {user ? user.name : 'Traveler'}! ✈️
          </h1>
          <p className="text-gray-600">Ready for your next adventure? Your Murree trip is tomorrow!</p>
        </div>


        {/* Quick Stats */}
        <div className="grid md:grid-cols-4 gap-6 mb-8">
          <div className="bg-white rounded-xl p-6 shadow-sm border">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Upcoming Trips</p>
                <p className="text-2xl font-bold text-gray-900">2</p>
              </div>
              <Calendar className="h-8 w-8 text-blue-600" />
            </div>
          </div>
          
          <div className="bg-white rounded-xl p-6 shadow-sm border">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Saved Tours</p>
                <p className="text-2xl font-bold text-gray-900">8</p>
              </div>
              <Bookmark className="h-8 w-8 text-green-600" />
            </div>
          </div>
          
          <div className="bg-white rounded-xl p-6 shadow-sm border">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Countries Visited</p>
                <p className="text-2xl font-bold text-gray-900">12</p>
              </div>
              <Globe className="h-8 w-8 text-purple-600" />
            </div>
          </div>
          
          <div className="bg-white rounded-xl p-6 shadow-sm border">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Total Experiences</p>
                <p className="text-2xl font-bold text-gray-900">24</p>
              </div>
              <Camera className="h-8 w-8 text-orange-600" />
            </div>
          </div>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-8">
            {/* Upcoming Trips */}
            <div className="bg-white rounded-xl shadow-sm border p-6">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl font-semibold text-gray-900">Upcoming Trips</h2>
                <Link to="/bookingdetails" className="text-blue-600 hover:text-blue-700 font-medium">View all</Link>
              </div>
              
              <div className="space-y-4">
                {upcomingTrips.map((trip) => (
                  <div key={trip.id} className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow">
                    <div className="flex items-start space-x-4">
                      <img 
                        src={trip.image} 
                        alt={trip.title}
                        className="w-20 h-20 rounded-lg object-cover"
                      />
                      <div className="flex-1">
                        <div className="flex items-start justify-between">
                          <div>
                            <h3 className="font-semibold text-gray-900 mb-1">{trip.title}</h3>
                            <div className="flex items-center text-sm text-gray-600 space-x-4">
                              <span className="flex items-center">
                                <Calendar className="h-4 w-4 mr-1" />
                                {trip.date} at {trip.time}
                              </span>
                              <span className="flex items-center">
                                <MapPin className="h-4 w-4 mr-1" />
                                {trip.location}
                              </span>
                            </div>
                            <div className="mt-2 flex items-center space-x-4 text-xs text-gray-500">
                              <span>{trip.participants} participants</span>
                              <span>Guide: {trip.guide}</span>
                            </div>
                          </div>
                          <div className="flex flex-col items-end space-y-2">
                            <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                              trip.status === 'confirmed' ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'
                            }`}>
                              {trip.status === 'confirmed' ? 'Confirmed' : 'Pending'}
                            </span>
                             <Link to="/bookingdetails" className="text-blue-600 hover:text-blue-700 font-medium">View all</Link>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Recommendations */}
            <div className="bg-white rounded-xl shadow-sm border p-6">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl font-semibold text-gray-900">Recommended for You</h2>
                <Link to="/SearchBooking" className="text-blue-600 hover:text-blue-700 font-medium">See more</Link>
              </div>
              
              <div className="grid md:grid-cols-2 gap-6">
                {recommendations.slice(0, 2).map((tour) => (
                  <div key={tour.id} className="border border-gray-200 rounded-lg overflow-hidden hover:shadow-md transition-shadow">
                    <div className="relative">
                      <img 
                        src={tour.image} 
                        alt={tour.title}
                        className="w-full h-40 object-cover"
                      />
                      <button className="absolute top-3 right-3 p-2 bg-white rounded-full shadow-md hover:bg-gray-50">
                        <Heart className="h-4 w-4 text-gray-600" />
                      </button>
                    </div>
                    <div className="p-4">
                      <h3 className="font-semibold text-gray-900 mb-2">{tour.title}</h3>
                      <div className="flex items-center space-x-2 text-sm text-gray-600 mb-2">
                        <div className="flex items-center">
                          <Star className="h-4 w-4 text-yellow-400 fill-current mr-1" />
                          <span>{tour.rating}</span>
                          <span className="ml-1">({tour.reviews})</span>
                        </div>
                        <span>• {tour.duration}</span>
                      </div>
                      <p className="text-xs text-blue-600 mb-3">{tour.reason}</p>
                      <div className="flex items-center justify-between">
                        <span className="text-lg font-bold text-gray-900">{tour.price}</span>
                       <Link to='/bookingdetails' className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors text-sm font-medium">
                          Book Now
                        </Link>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Recent Activity */}
            <div className="bg-white rounded-xl shadow-sm border p-6">
              <h2 className="text-xl font-semibold text-gray-900 mb-6">Recent Activity</h2>
              <div className="space-y-4">
                {recentActivity.map((activity) => {
                  const IconComponent = activity.icon;
                  return (
                    <div key={activity.id} className="flex items-center space-x-3 py-2">
                      <div className="p-2 bg-gray-100 rounded-lg">
                        <IconComponent className="h-4 w-4 text-gray-600" />
                      </div>
                      <div className="flex-1">
                        <p className="text-sm text-gray-900">
                          <span className="font-medium">{activity.action}</span> {activity.item}
                        </p>
                        <p className="text-xs text-gray-500">{activity.time}</p>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Notifications */}
            <div className="bg-white rounded-xl shadow-sm border p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Notifications</h3>
              <div className="space-y-3">
                {notifications.map((notification) => (
                  <div 
                    key={notification.id} 
                    className={`p-3 rounded-lg border cursor-pointer ${
                      notification.read ? 'bg-gray-50 border-gray-200' : 'bg-blue-50 border-blue-200'
                    }`}
                    onClick={() => markNotificationRead(notification.id)}
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <p className={`text-sm ${notification.read ? 'text-gray-700' : 'text-gray-900 font-medium'}`}>
                          {notification.message}
                        </p>
                        <p className="text-xs text-gray-500 mt-1">{notification.time}</p>
                      </div>
                      {!notification.read && (
                        <div className="w-2 h-2 bg-blue-600 rounded-full mt-1"></div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Weather Widget */}
            <div className="bg-gradient-to-br from-blue-500 to-blue-600 rounded-xl p-6 text-white">
              <h3 className="text-lg font-semibold mb-2">Weather in Florence</h3>
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-2xl font-bold">24°C</p>
                  <p className="text-blue-100">Sunny</p>
                </div>
                <div className="text-right">
                  <p className="text-sm text-blue-100">Tomorrow</p>
                  <p className="text-sm">Perfect for sightseeing!</p>
                </div>
              </div>
            </div>

            {/* Quick Actions */}
            <div className="bg-white rounded-xl shadow-sm border p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Quick Actions</h3>
              <div className="space-y-3">
                <Link to="/SearchBooking" className="w-full flex items-center space-x-3 p-3 rounded-lg border border-gray-200 hover:bg-gray-50 transition-colors">
                  <Search className="h-5 w-5 text-gray-600" />
                  <span className="text-sm font-medium text-gray-900">Find new tours</span>
                </Link>
               <Link to="/SearchBooking"className="w-full flex items-center space-x-3 p-3 rounded-lg border border-gray-200 hover:bg-gray-50 transition-colors">
                  <Calendar className="h-5 w-5 text-gray-600" />
                  <span className="text-sm font-medium text-gray-900">Plan a trip</span>
                </Link>
                <button className="w-full flex items-center space-x-3 p-3 rounded-lg border border-gray-200 hover:bg-gray-50 transition-colors">
                  <MessageCircle className="h-5 w-5 text-gray-600" />
                  <span className="text-sm font-medium text-gray-900">Contact support</span>
                </button>
              </div>
            </div>

            {/* Travel Progress */}
            <div className="bg-white rounded-xl shadow-sm border p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Travel Progress</h3>
              <div className="space-y-4">
                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span className="text-gray-600">Explorer Level</span>
                    <span className="font-medium">Level 3</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div className="bg-gradient-to-r from-blue-500 to-blue-600 h-2 rounded-full" style={{width: '65%'}}></div>
                  </div>
                  <p className="text-xs text-gray-500 mt-1">8 more tours to reach Level 4</p>
                </div>
                
                <div className="pt-3 border-t border-gray-200">
                  <p className="text-sm font-medium text-gray-900 mb-2">Achievements</p>
                  <div className="flex space-x-2">
                    <div className="p-2 bg-yellow-100 rounded-lg">
                      <Star className="h-4 w-4 text-yellow-600" />
                    </div>
                    <div className="p-2 bg-green-100 rounded-lg">
                      <Globe className="h-4 w-4 text-green-600" />
                    </div>
                    <div className="p-2 bg-purple-100 rounded-lg">
                      <Camera className="h-4 w-4 text-purple-600" />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;