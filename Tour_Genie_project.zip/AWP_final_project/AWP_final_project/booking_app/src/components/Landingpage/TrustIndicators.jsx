const TrustIndicators = () => (
  <section className="bg-gray-50 py-12">
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      <div className="grid md:grid-cols-4 gap-8 text-center">
        <div>
          <div className="text-3xl font-bold text-blue-600 mb-2">2M+</div>
          <div className="text-gray-600">Happy customers</div>
        </div>
        <div>
          <div className="text-3xl font-bold text-blue-600 mb-2">50K+</div>
          <div className="text-gray-600">Tours & activities</div>
        </div>
        <div>
          <div className="text-3xl font-bold text-blue-600 mb-2">150+</div>
          <div className="text-gray-600">Countries</div>
        </div>
        <div>
          <div className="text-3xl font-bold text-blue-600 mb-2">4.5★</div>
          <div className="text-gray-600">Average rating</div>
        </div>
      </div>
    </div>
  </section>
);

export default TrustIndicators;
