import React from 'react';
import { Star } from 'lucide-react';

const Sidebar = () => (
  <div className="space-y-6">
 
    <div className="bg-white rounded-xl shadow-lg p-6">
      <h3 className="text-lg font-semibold text-gray-900 mb-4">Why book with Tour Genie?</h3>
      <div className="space-y-3">
        {["Best price guarantee", "Free cancellation", "Instant confirmation"].map((title, i) => (
          <div key={i} className="flex items-start space-x-3">
            <div className="w-2 h-2 bg-green-500 rounded-full mt-2"></div>
            <div>
              <p className="font-medium text-gray-900">{title}</p>
              <p className="text-sm text-gray-600">
                {title === "Best price guarantee" && "Find it cheaper elsewhere? We'll refund the difference"}
                {title === "Free cancellation" && "Cancel up to 24 hours before your tour"}
                {title === "Instant confirmation" && "Get your tickets immediately via email"}
              </p>
            </div>
          </div>
        ))}
      </div>
    </div>

    <div className="bg-white rounded-xl shadow-lg p-6">
      <h3 className="text-lg font-semibold text-gray-900 mb-4">What travelers say</h3>
      <div className="space-y-4">
        {[{
          name: "Sarah .",
          text: "Absolutely incredible experience! The guide was knowledgeable and the basilica was breathtaking."
        }, {
          name: "Marco R.",
          text: "Perfect day trip from Rome. Well organized and great value for money."
        }].map((review, i) => (
          <div key={i} className="border-l-4 border-blue-500 pl-4">
            <div className="flex items-center mb-2">
              <div className="flex">
                {[...Array(5)].map((_, i) => <Star key={i} className="h-4 w-4 text-yellow-400 fill-current" />)}
              </div>
              <span className="ml-2 text-sm text-gray-600">{review.name}</span>
            </div>
            <p className="text-sm text-gray-700">"{review.text}"</p>
          </div>
        ))}
      </div>
    </div>

 
    <div className="bg-blue-50 rounded-xl p-6">
      <h3 className="text-lg font-semibold text-gray-900 mb-2">Need help?</h3>
      <p className="text-sm text-gray-600 mb-4">Our travel experts are here to help you plan the perfect trip.</p>
      <button className="w-full bg-blue-600 text-white py-2 rounded-lg hover:bg-blue-700 transition-colors font-medium">
        Contact Support
      </button>
    </div>
  </div>
);

export default Sidebar;