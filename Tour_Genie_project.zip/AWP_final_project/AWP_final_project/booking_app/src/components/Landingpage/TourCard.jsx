import React from 'react';
import { Star } from 'lucide-react';
import { Link } from 'react-router-dom';

const TourCard = ({ tour }) => (
  <div className="bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-xl transition-shadow">
    <div className="md:flex">
      <div className="md:w-80 relative">
        <img src={tour.image} alt={tour.title} className="w-full h-48 md:h-full object-cover" />
        <div className="absolute top-3 left-3">
          <span className={`px-3 py-1 rounded-full text-xs font-semibold text-white ${
            tour.badge === 'Bestseller' ? 'bg-orange-500' :
            tour.badge === 'Premium' ? 'bg-purple-600' : 'bg-green-600'
          }`}>
            {tour.badge}
          </span>
        </div>
      </div>
      <div className="p-6 flex-1">
        <h3 className="text-xl font-semibold text-gray-900 leading-tight mb-2">{tour.title}</h3>
        <div className="flex items-center space-x-4 text-sm text-gray-600 mb-4">
          <div className="flex items-center">
            <Star className="h-4 w-4 text-yellow-400 fill-current mr-1" />
            <span className="font-medium">{tour.rating}</span>
            <span className="ml-1">({tour.reviews} reviews)</span>
          </div>
          <span>• {tour.duration}</span>
        </div>
        <div className="mb-4">
          <div className="flex flex-wrap gap-2">
            {tour.highlights.map((highlight, index) => (
              <span key={index} className="px-2 py-1 bg-gray-100 text-gray-700 text-xs rounded-full">
                {highlight}
              </span>
            ))}
          </div>
        </div>
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            {tour.originalPrice && (
              <span className="text-gray-400 line-through text-sm">{tour.originalPrice}</span>
            )}
            <span className="text-2xl font-bold text-gray-900">{tour.price}</span>
            <span className="text-gray-600 text-sm">per person</span>
          </div>
          <Link to='/bookingdetails' className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 transition-colors font-medium">
            Book Now
          </Link>
        </div>
      </div>
    </div>
  </div>
);

export default TourCard;