import Navbar from "./Navbar";
import HeroSection from "./HeroSection";
import Filters from "./Filters";
import TourList from "./TourList";
import Sidebar from "./Sidebar";
import TrustIndicators from "./TrustIndicators";

const LandingPage = () => {
  return (
    <div className="min-h-screen bg-white">
      <Navbar />
      <HeroSection />
      <Filters />
      <section className="py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2">
              <TourList />
            </div>
            <Sidebar />
          </div>
        </div>
      </section>
      <TrustIndicators />
    </div>
  );
};

export default LandingPage;
