import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';

const HeroSection = () => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    setIsVisible(true);
  }, []);

  return (
    <section className="relative bg-gradient-to-r from-blue-600 via-blue-700 to-blue-800 text-white py-20 overflow-hidden">
      {/* Animated background circles */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-20 left-20 w-64 h-64 bg-white rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-20 right-20 w-48 h-48 bg-blue-200 rounded-full blur-2xl animate-pulse delay-1000"></div>
      </div>

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className={`max-w-3xl transform transition-all duration-1000 ${isVisible ? 'translate-y-0 opacity-100' : 'translate-y-10 opacity-0'}`}>
          <h1 className="text-5xl md:text-6xl font-bold mb-6 leading-tight">
            Plan Your Journey from
            <span className="block text-blue-200 bg-gradient-to-r from-blue-200 to-blue-100 bg-clip-text text-transparent animate-pulse">
              Islamabad to Hunza Valley
            </span>
          </h1>
          
          <p className="text-xl text-blue-100 mb-8 leading-relaxed">
            Discover the breathtaking beauty of Pakistan’s northern areas — culture, adventure, and scenic valleys await you.
          </p>

          <div className={`bg-white rounded-xl p-6 shadow-2xl hover:shadow-3xl transition-all duration-500 transform ${isVisible ? 'translate-y-0 opacity-100' : 'translate-y-5 opacity-0'} delay-300`}>
            <div className="grid md:grid-cols-4 gap-4">
              <div className="md:col-span-2">
                <label className="block text-sm font-medium text-gray-700 mb-2">Destination</label>
                <input 
                  type="text" 
                  placeholder="e.g., Swat, Hunza, Murree" 
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-300 hover:border-blue-400 placeholder:text-black focus:scale-105"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Date</label>
                <input 
                  type="date" 
                  className="w-full px-4 py-3 border text-black border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-300 hover:border-blue-400 focus:scale-105"
                />
              </div>
              <div className="flex items-end">
                <button className="w-full bg-gradient-to-r from-orange-500 to-orange-600 text-white py-3 rounded-lg hover:from-orange-600 hover:to-orange-700 font-semibold transition-all duration-300 transform hover:scale-105 hover:shadow-lg active:scale-95">
                  Search
                </button>
              </div>
            </div>            
          </div>
        </div>
      </div>

      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-1/4 left-1/4 w-2 h-2 bg-white rounded-full opacity-20 animate-ping"></div>
        <div className="absolute top-3/4 left-3/4 w-1 h-1 bg-blue-200 rounded-full opacity-30 animate-ping delay-500"></div>
        <div className="absolute top-1/2 right-1/4 w-1.5 h-1.5 bg-white rounded-full opacity-25 animate-ping delay-1000"></div>
      </div>
    </section>
  );
};

export default HeroSection;
