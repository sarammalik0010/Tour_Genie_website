import TourCard from './TourCard';

const tourData = [
  {
    id: 1,
    title: 'Full-Day Hunza Valley Tour from Islamabad',
    image: 'https://images.unsplash.com/photo-1523906834658-6e24ef2386f9?w=400&h=250&fit=crop',
    duration: '13 hours',
    rating: 4.6,
    reviews: 2847,
    price: 'Rs 8,500',
    originalPrice: 'Rs 9,500',
    highlights: ['AC transport', 'Professional local guide', 'Lunch included', 'Sightseeing spots'],
    badge: 'Bestseller'
  },
  {
    id: 2,
    title: 'Private Day Trip: Swat Valley & Malam Jabba',
    image: 'https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?w=400&h=250&fit=crop',
    duration: '12 hours',
    rating: 4.8,
    reviews: 1523,
    price: 'Rs 22,000',
    highlights: ['Private vehicle', 'Custom stops', 'Chair lift ride', 'Guide included'],
    badge: 'Premium'
  },
  {
    id: 3,
    title: 'Cultural Tour: Lahore Fort & Badshahi Mosque',
    image: 'https://images.unsplash.com/photo-1529260830199-42c24126f198?w=400&h=250&fit=crop',
    duration: '3 hours',
    rating: 4.7,
    reviews: 956,
    price: 'Rs 1,500',
    highlights: ['Historical insights', 'English/Urdu guide', 'Entry tickets included', 'Group tour'],
    badge: 'Cultural'
  }
];

const TourList = () => (
  <div className="space-y-6">
    {tourData.map((tour) => <TourCard key={tour.id} tour={tour} />)}
  </div>
);

export default TourList;
