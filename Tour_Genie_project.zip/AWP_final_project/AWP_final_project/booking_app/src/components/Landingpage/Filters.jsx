import React from 'react';

const Filters = () => (
  <section className="bg-gray-50 py-6 border-b">
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center space-x-4">
          <span className="text-gray-700 font-medium">12 results</span>
          <div className="flex space-x-2">
            {["Duration", "Price", "Rating", "More filters"].map((filter, i) => (
              <button key={i} className="px-4 py-2 bg-white border border-gray-300 rounded-lg text-sm font-medium hover:bg-gray-50">{filter}</button>
            ))}
          </div>
        </div>
        <div className="flex items-center space-x-2">
          <span className="text-gray-700 text-sm">Sort by:</span>
          <select className="border border-gray-300 rounded-lg px-3 py-2 text-sm">
            <option>Recommended</option>
            <option>Price: Low to High</option>
            <option>Price: High to Low</option>
            <option>Duration</option>
            <option>Customer Rating</option>
          </select>
        </div>
      </div>
    </div>
  </section>
);

export default Filters;