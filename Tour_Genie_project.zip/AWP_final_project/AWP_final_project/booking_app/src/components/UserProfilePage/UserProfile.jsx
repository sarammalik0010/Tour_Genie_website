import React, { useState, useEffect } from 'react';
import axios from 'axios';

const UserProfile = () => {
  const [userData, setUserData] = useState({
    name: '',
    email: '',
    preference: '',
    gender: 'Male', // added gender
  });

  const [loading, setLoading] = useState(true);
  const [message, setMessage] = useState('');

  useEffect(() => {
    axios.get('http://localhost:3000/users/profile')
      .then((res) => {
        setUserData(res.data);
        setLoading(false);
      })
      .catch((err) => {
        console.error("Failed to fetch user profile", err);
        setLoading(false);
      });
  }, []);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setUserData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSave = () => {
    axios.put('/api/user/profile', userData)
      .then(() => {
        setMessage('Profile updated successfully!');
        setTimeout(() => setMessage(''), 3000);
      })
      .catch((err) => {
        console.error("Update failed", err);
        setMessage("Failed to update profile");
        setTimeout(() => setMessage(''), 3000);
      });
  };

  const getAvatar = () => {
    return userData.gender === 'Female'
      ? 'https://cdn-icons-png.flaticon.com/512/847/847969.png'
      : 'https://cdn-icons-png.flaticon.com/512/847/847969.png'; // You can use a different URL for male
  };

  if (loading) {
    return (
      <div className="text-center py-20 text-blue-500 text-lg animate-pulse">
        Loading profile...
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-white py-10 px-4">
      <div className="max-w-3xl mx-auto bg-white shadow-xl rounded-2xl p-8 transition-all duration-500 hover:shadow-2xl">
        <div className="flex items-center space-x-6 mb-8 animate-fadeIn">
          <img
            src={getAvatar()}
            alt="avatar"
            className="w-24 h-24 rounded-full border-4 border-blue-500 shadow-lg"
          />
          <div>
            <h2 className="text-3xl font-bold text-blue-600">User Profile</h2>
            <p className="text-gray-500 text-sm">Manage your account settings and preferences.</p>
          </div>
        </div>

        <div className="space-y-4">
          {/* Name */}
          <div>
            <label className="block text-sm font-medium text-gray-700">Name</label>
            <input
              name="name"
              type="text"
              value={userData.name}
              onChange={handleChange}
              className="mt-1 w-full p-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-400 transition"
            />
          </div>

          {/* Email */}
          <div>
            <label className="block text-sm font-medium text-gray-700">Email</label>
            <input
              name="email"
              type="email"
              value={userData.email}
              onChange={handleChange}
              className="mt-1 w-full p-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-400 transition"
            />
          </div>

          {/* Gender */}
          <div>
            <label className="block text-sm font-medium text-gray-700">Gender</label>
            <select
              name="gender"
              value={userData.gender}
              onChange={handleChange}
              className="mt-1 w-full p-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-400 transition"
            >
              <option>Male</option>
              <option>Female</option>
            </select>
          </div>

          {/* Preference */}
          <div>
            <label className="block text-sm font-medium text-gray-700">Travel Preference</label>
            <select
              name="preference"
              value={userData.preference}
              onChange={handleChange}
              className="mt-1 w-full p-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-400 transition"
            >
              <option>Adventure</option>
              <option>Relaxation</option>
              <option>Culture</option>
              <option>Nature</option>
            </select>
          </div>

          {/* Button */}
          <button
            onClick={handleSave}
            className="w-full bg-blue-600 hover:bg-blue-700 text-white font-semibold py-3 px-4 rounded-lg shadow-md transition transform hover:scale-105"
          >
            Save Changes
          </button>

          {message && (
            <p className="text-center text-green-600 text-sm mt-3 animate-fadeIn">
              {message}
            </p>
          )}
        </div>
      </div>
    </div>
  );
};

export default UserProfile;
