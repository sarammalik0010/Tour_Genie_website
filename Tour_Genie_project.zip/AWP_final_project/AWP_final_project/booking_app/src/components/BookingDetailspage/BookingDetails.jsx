import { useState } from 'react';
import {
  MapPin, Star, Plane, Train, Car, Hotel, Calendar, Clock, 
  User, Phone, Mail, CheckCircle, AlertCircle, Download, 
  Edit3, X, Wifi, Coffee, Utensils, Dumbbell, Car as CarIcon,
  ArrowRight, ArrowLeft, CreditCard, Shield, FileText, MessageCircle,
  Link
} from 'lucide-react';

const BookingDetailsPage = () => {
  const [activeModal, setActiveModal] = useState(null);

  // Mock booking data
  const bookingData = {
    id: "TG-2025-001847",
    status: "confirmed",
    bookingDate: "2025-06-25",
    totalAmount: 459,
    currency: "EUR",
    travelerInfo: {
      name: "Sarah Johnson",
      email: "sarah.johnson@email.com",
      phone: "+1 (555) 123-4567",
      travelers: 2
    },
    hotel: {
      id: 1,
      name: "Hotel Davanzati",
      rating: 4.6,
      reviews: 1284,
      checkIn: "2025-06-30",
      checkOut: "2025-07-02",
      nights: 2,
      rooms: 1,
      roomType: "Deluxe Double Room",
      price: 145,
      totalPrice: 290,
      address: "Via di Porta Rossa, 5, 50123 Florence, Italy",
      image: "https://images.unsplash.com/photo-1551882547-ff40c63fe5fa?w=500&h=300&fit=crop",
      amenities: ["Free WiFi", "Breakfast Included", "Air Conditioning", "Parking", "24/7 Reception"],
      cancellationPolicy: "Free cancellation until 24 hours before check-in",
      confirmationNumber: "HDV-789456"
    },
    transport: {
      id: 1,
      type: "train",
      operator: "Trenitalia",
      from: "Roma Termini",
      to: "Firenze Santa Maria Novella",
      departure: "2025-06-30",
      departureTime: "08:35",
      arrival: "2025-06-30",
      arrivalTime: "10:05",
      duration: "1h 30m",
      price: 25,
      passengers: 2,
      totalPrice: 50,
      class: "Standard",
      seats: ["12A", "12B"],
      ticketNumber: "TN-887654321",
      features: ["Direct", "WiFi", "Power outlets"]
    },
    flight: {
      id: 1,
      airline: "ITA Airways",
      flightNumber: "AZ 1234",
      from: "Rome Fiumicino (FCO)",
      to: "Florence (FLR)",
      departure: "2025-07-02",
      departureTime: "18:25",
      arrival: "2025-07-02",
      arrivalTime: "19:30",
      duration: "1h 05m",
      price: 89,
      passengers: 2,
      totalPrice: 178,
      class: "Economy",
      seats: ["14A", "14B"],
      bookingReference: "ITA789XYZ",
      baggage: "23kg checked baggage included"
    }
  };

  const getStatusColor = (status) => {
    const colors = {
      confirmed: 'text-green-600 bg-green-100',
      pending: 'text-yellow-600 bg-yellow-100',
      cancelled: 'text-red-600 bg-red-100'
    };
    return colors[status] || 'text-gray-600 bg-gray-100';
  };

  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };



  const ModificationModal = ({ type, booking, onClose }) => (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        <div className="p-6 border-b border-gray-200">
          <div className="flex justify-between items-center">
            <h3 className="text-xl font-semibold text-gray-900">
              Modify {type === 'hotel' ? 'Hotel' : type === 'transport' ? 'Transport' : 'Flight'} Booking
            </h3>
            <button onClick={onClose} className="text-gray-400 hover:text-gray-600">
              <X className="h-6 w-6" />
            </button>
          </div>
        </div>
        
        <div className="p-6">
          {type === 'hotel' && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Check-in Date</label>
                  <input 
                    type="date" 
                    defaultValue={booking.checkIn}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Check-out Date</label>
                  <input 
                    type="date" 
                    defaultValue={booking.checkOut}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                  />
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Room Type</label>
                <select className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500">
                  <option value="deluxe">Deluxe Double Room</option>
                  <option value="standard">Standard Double Room</option>
                  <option value="suite">Suite</option>
                </select>
              </div>
            </div>
          )}
          
          {type === 'transport' && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Departure Date</label>
                  <input 
                    type="date" 
                    defaultValue={booking.departure}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Departure Time</label>
                  <select className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500">
                    <option value="08:35">08:35 - €25</option>
                    <option value="12:15">12:15 - €30</option>
                    <option value="16:45">16:45 - €25</option>
                  </select>
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Class</label>
                <select className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500">
                  <option value="standard">Standard - €0</option>
                  <option value="first">First Class - €15</option>
                </select>
              </div>
            </div>
          )}

          <div className="mt-6 bg-yellow-50 border border-yellow-200 rounded-lg p-4">
            <div className="flex items-start">
              <AlertCircle className="h-5 w-5 text-yellow-600 mt-0.5 mr-3" />
              <div>
                <h4 className="text-sm font-medium text-yellow-800">Modification Fee</h4>
                <p className="text-sm text-yellow-700">A modification fee of €15 may apply for changes made less than 24 hours before travel.</p>
              </div>
            </div>
          </div>

          <div className="mt-6 flex space-x-3">
            <button className="flex-1 bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700 transition-colors font-medium">
              Confirm Changes
            </button>
            <button 
              onClick={onClose}
              className="flex-1 bg-gray-100 text-gray-700 py-2 px-4 rounded-lg hover:bg-gray-200 transition-colors font-medium"
            >
              Cancel
            </button>
          </div>
        </div>
      </div>
    </div>
  );

  const CancellationModal = ({ type, booking, onClose }) => (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-xl max-w-md w-full">
        <div className="p-6 border-b border-gray-200">
          <div className="flex justify-between items-center">
            <h3 className="text-xl font-semibold text-gray-900">Cancel Booking</h3>
            <button onClick={onClose} className="text-gray-400 hover:text-gray-600">
              <X className="h-6 w-6" />
            </button>
          </div>
        </div>
        
        <div className="p-6">
          <div className="text-center mb-6">
            <div className="w-12 h-12 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <AlertCircle className="h-6 w-6 text-red-600" />
            </div>
            <h4 className="text-lg font-medium text-gray-900 mb-2">
              Are you sure you want to cancel this {type}?
            </h4>
            <p className="text-gray-600 text-sm">
              {type === 'hotel' ? booking.cancellationPolicy : 
               type === 'transport' ? 'Free cancellation until 2 hours before departure' :
               'Cancellation fees may apply based on airline policy'}
            </p>
          </div>

          <div className="bg-gray-50 rounded-lg p-4 mb-6">
            <div className="flex justify-between items-center">
              <span className="text-sm text-gray-600">Refund Amount</span>
              <span className="font-semibold text-gray-900">
                €{type === 'hotel' ? booking.totalPrice : 
                    type === 'transport' ? booking.totalPrice : 
                    booking.totalPrice}
              </span>
            </div>
          </div>

          <div className="flex space-x-3">
            <button className="flex-1 bg-red-600 text-white py-2 px-4 rounded-lg hover:bg-red-700 transition-colors font-medium">
              Cancel Booking
            </button>
            <button 
              onClick={onClose}
              className="flex-1 bg-gray-100 text-gray-700 py-2 px-4 rounded-lg hover:bg-gray-200 transition-colors font-medium"
            >
              Keep Booking
            </button>
          </div>
        </div>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-gray-50">
       

        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          {/* Booking Header */}
        <div className="bg-white rounded-xl shadow-sm border p-6 mb-8">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between">
            <div>
              <h1 className="text-2xl font-bold text-gray-900 mb-2">Booking Details</h1>
              <div className="flex items-center space-x-4 text-sm text-gray-600">
                <span>Booking ID: <span className="font-medium text-gray-900">{bookingData.id}</span></span>
                <span>•</span>
                <span>Booked on {formatDate(bookingData.bookingDate)}</span>
              </div>
            </div>
            <div className="mt-4 md:mt-0">
              <div className="flex items-center space-x-3">
                <span className={`px-3 py-1 rounded-full text-sm font-medium ${getStatusColor(bookingData.status)}`}>
                  <CheckCircle className="h-4 w-4 inline mr-1" />
                  {bookingData.status.charAt(0).toUpperCase() + bookingData.status.slice(1)}
                </span>
                <div className="text-right">
                  <div className="text-sm text-gray-600">Total Amount</div>
                  <div className="text-xl font-bold text-gray-900">€{bookingData.totalAmount}</div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Traveler Information */}
        <div className="bg-white rounded-xl shadow-sm border p-6 mb-8">
          <h2 className="text-xl font-semibold text-gray-900 mb-4">Traveler Information</h2>
          <div className="grid md:grid-cols-2 gap-6">
            <div className="space-y-3">
              <div className="flex items-center space-x-3">
                <User className="h-5 w-5 text-gray-400" />
                <div>
                  <div className="text-sm text-gray-600">Primary Traveler</div>
                  <div className="font-medium text-gray-900">{bookingData.travelerInfo.name}</div>
                </div>
              </div>
              <div className="flex items-center space-x-3">
                <Mail className="h-5 w-5 text-gray-400" />
                <div>
                  <div className="text-sm text-gray-600">Email</div>
                  <div className="font-medium text-gray-900">{bookingData.travelerInfo.email}</div>
                </div>
              </div>
            </div>
            <div className="space-y-3">
              <div className="flex items-center space-x-3">
                <Phone className="h-5 w-5 text-gray-400" />
                <div>
                  <div className="text-sm text-gray-600">Phone</div>
                  <div className="font-medium text-gray-900">{bookingData.travelerInfo.phone}</div>
                </div>
              </div>
              <div className="flex items-center space-x-3">
                <User className="h-5 w-5 text-gray-400" />
                <div>
                  <div className="text-sm text-gray-600">Number of Travelers</div>
                  <div className="font-medium text-gray-900">{bookingData.travelerInfo.travelers}</div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Hotel Booking */}
        <div className="bg-white rounded-xl shadow-sm border p-6 mb-8">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-semibold text-gray-900 flex items-center">
              <Hotel className="h-6 w-6 mr-2 text-blue-600" />
              Hotel Accommodation
            </h2>
            <div className="flex space-x-2">
              <button 
                onClick={() => setActiveModal('modify-hotel')}
                className="flex items-center space-x-1 px-3 py-2 bg-blue-50 text-blue-600 rounded-lg hover:bg-blue-100 transition-colors text-sm"
              >
                <Edit3 className="h-4 w-4" />
                <span>Modify</span>
              </button>
              <button 
                onClick={() => setActiveModal('cancel-hotel')}
                className="flex items-center space-x-1 px-3 py-2 bg-red-50 text-red-600 rounded-lg hover:bg-red-100 transition-colors text-sm"
              >
                <X className="h-4 w-4" />
                <span>Cancel</span>
              </button>
            </div>
          </div>

          <div className="md:flex space-y-4 md:space-y-0 md:space-x-6">
            <div className="md:w-80">
              <img src={bookingData.hotel.image} alt={bookingData.hotel.name} className="w-full h-48 object-cover rounded-lg" />
            </div>
            <div className="flex-1">
              <div className="flex items-start justify-between mb-3">
                <div>
                  <h3 className="text-lg font-semibold text-gray-900">{bookingData.hotel.name}</h3>
                  <p className="text-sm text-gray-600 mb-2">{bookingData.hotel.address}</p>
                  <div className="flex items-center space-x-2 mb-3">
                    <div className="flex">
                      {Array(Math.floor(bookingData.hotel.rating)).fill(null).map((_, i) => (
                        <Star key={i} className="h-4 w-4 text-yellow-400 fill-current" />
                      ))}
                    </div>
                    <span className="text-sm font-medium">{bookingData.hotel.rating}</span>
                    <span className="text-sm text-gray-600">({bookingData.hotel.reviews} reviews)</span>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4 mb-4">
                <div>
                  <div className="text-sm text-gray-600">Check-in</div>
                  <div className="font-medium text-gray-900">{formatDate(bookingData.hotel.checkIn)}</div>
                </div>
                <div>
                  <div className="text-sm text-gray-600">Check-out</div>
                  <div className="font-medium text-gray-900">{formatDate(bookingData.hotel.checkOut)}</div>
                </div>
                <div>
                  <div className="text-sm text-gray-600">Room Type</div>
                  <div className="font-medium text-gray-900">{bookingData.hotel.roomType}</div>
                </div>
                <div>
                  <div className="text-sm text-gray-600">Confirmation Number</div>
                  <div className="font-medium text-gray-900">{bookingData.hotel.confirmationNumber}</div>
                </div>
              </div>

              <div className="mb-4">
                <div className="text-sm text-gray-600 mb-2">Amenities</div>
                <div className="flex flex-wrap gap-2">
                  {bookingData.hotel.amenities.map((amenity, index) => (
                    <span key={index} className="px-2 py-1 bg-gray-100 text-gray-700 text-xs rounded-full">
                      {amenity}
                    </span>
                  ))}
                </div>
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <div className="text-sm text-gray-600">Total Cost</div>
                  <div className="text-lg font-bold text-gray-900">€{bookingData.hotel.totalPrice}</div>
                  <div className="text-xs text-gray-500">{bookingData.hotel.nights} nights × €{bookingData.hotel.price}</div>
                </div>
                <div className="text-right">
                  <div className="text-xs text-green-600 flex items-center">
                    <CheckCircle className="h-3 w-3 mr-1" />
                    {bookingData.hotel.cancellationPolicy}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Transport Booking */}
        <div className="bg-white rounded-xl shadow-sm border p-6 mb-8">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-semibold text-gray-900 flex items-center">
              <Train className="h-6 w-6 mr-2 text-blue-600" />
              Transportation
            </h2>
            <div className="flex space-x-2">
              <button 
                onClick={() => setActiveModal('modify-transport')}
                className="flex items-center space-x-1 px-3 py-2 bg-blue-50 text-blue-600 rounded-lg hover:bg-blue-100 transition-colors text-sm"
              >
                <Edit3 className="h-4 w-4" />
                <span>Modify</span>
              </button>
              <button 
                onClick={() => setActiveModal('cancel-transport')}
                className="flex items-center space-x-1 px-3 py-2 bg-red-50 text-red-600 rounded-lg hover:bg-red-100 transition-colors text-sm"
              >
                <X className="h-4 w-4" />
                <span>Cancel</span>
              </button>
            </div>
          </div>

          <div className="border border-gray-200 rounded-lg p-4">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center space-x-4">
                <div className="p-3 bg-blue-100 rounded-lg">
                  <Train className="h-6 w-6 text-blue-600" />
                </div>
                <div>
                  <h3 className="text-lg font-semibold text-gray-900">{bookingData.transport.operator}</h3>
                  <div className="text-sm text-gray-600">Ticket: {bookingData.transport.ticketNumber}</div>
                </div>
              </div>
              <div className="text-right">
                <div className="text-lg font-bold text-gray-900">€{bookingData.transport.totalPrice}</div>
                <div className="text-sm text-gray-600">{bookingData.transport.passengers} passengers</div>
              </div>
            </div>

            <div className="border-t border-gray-200 pt-4">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <div className="text-sm text-gray-600">Departure</div>
                  <div className="font-medium text-gray-900">{bookingData.transport.from}</div>
                  <div className="text-sm text-gray-600">
                    {formatDate(bookingData.transport.departure)} at {bookingData.transport.departureTime}
                  </div>
                </div>
                <div>
                  <div className="text-sm text-gray-600">Arrival</div>
                  <div className="font-medium text-gray-900">{bookingData.transport.to}</div>
                  <div className="text-sm text-gray-600">
                    {formatDate(bookingData.transport.arrival)} at {bookingData.transport.arrivalTime}
                  </div>
                </div>
                <div>
                  <div className="text-sm text-gray-600">Seats</div>
                  <div className="font-medium text-gray-900">{bookingData.transport.seats.join(', ')}</div>
                  <div className="text-sm text-gray-600">{bookingData.transport.class} Class</div>
                </div>
              </div>

              <div className="mt-4">
                <div className="text-sm text-gray-600 mb-2">Features</div>
                <div className="flex flex-wrap gap-2">
                  {bookingData.transport.features.map((feature, index) => (
                    <span key={index} className="px-2 py-1 bg-gray-100 text-gray-700 text-xs rounded-full">
                      {feature}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Flight Booking */}
        <div className="bg-white rounded-xl shadow-sm border p-6 mb-8">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-semibold text-gray-900 flex items-center">
              <Plane className="h-6 w-6 mr-2 text-blue-600" />
              Flight
            </h2>
            <div className="flex space-x-2">
              <button 
                onClick={() => setActiveModal('modify-flight')}
                className="flex items-center space-x-1 px-3 py-2 bg-blue-50 text-blue-600 rounded-lg hover:bg-blue-100 transition-colors text-sm"
              >
                <Edit3 className="h-4 w-4" />
                <span>Modify</span>
              </button>
              <button 
                onClick={() => setActiveModal('cancel-flight')}
                className="flex items-center space-x-1 px-3 py-2 bg-red-50 text-red-600 rounded-lg hover:bg-red-100 transition-colors text-sm"
              >
                <X className="h-4 w-4" />
                <span>Cancel</span>
              </button>
            </div>
          </div>

          <div className="border border-gray-200 rounded-lg p-4">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center space-x-4">
                <div className="p-3 bg-blue-100 rounded-lg">
                  <Plane className="h-6 w-6 text-blue-600" />
                </div>
                <div>
                  <h3 className="text-lg font-semibold text-gray-900">{bookingData.flight.airline}</h3>
                  <div className="text-sm text-gray-600">Flight {bookingData.flight.flightNumber}</div>
                  <div className="text-sm text-gray-600">Booking: {bookingData.flight.bookingReference}</div>
                </div>
              </div>
              <div className="text-right">
                <div className="text-lg font-bold text-gray-900">€{bookingData.flight.totalPrice}</div>
                <div className="text-sm text-gray-600">{bookingData.flight.passengers} passengers</div>
              </div>
            </div>

            <div className="border-t border-gray-200 pt-4">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <div className="text-sm text-gray-600">Departure</div>
                  <div className="font-medium text-gray-900">{bookingData.flight.from}</div>
                  <div className="text-sm text-gray-600">
                    {formatDate(bookingData.flight.departure)} at {bookingData.flight.departureTime}
                  </div>
                </div>
                <div>
                  <div className="text-sm text-gray-600">Arrival</div>
                  <div className="font-medium text-gray-900">{bookingData.flight.to}</div>
                  <div className="text-sm text-gray-600">
                    {formatDate(bookingData.flight.arrival)} at {bookingData.flight.arrivalTime}
                  </div>
                </div>
                <div>
                  <div className="text-sm text-gray-600">Seats</div>
                  <div className="font-medium text-gray-900">{bookingData.flight.seats.join(', ')}</div>
                  <div className="text-sm text-gray-600">{bookingData.flight.class} Class</div>
                </div>
              </div>

              <div className="mt-4">
                <div className="text-sm text-gray-600 mb-2">Baggage</div>
                <div className="text-sm text-gray-900">{bookingData.flight.baggage}</div>
              </div>
            </div>
          </div>
        </div>

        {/* Actions & Support */}
        <div className="grid md:grid-cols-2 gap-6">
          {/* Quick Actions */}
          <div className="bg-white rounded-xl shadow-sm border p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Quick Actions</h3>
            <div className="space-y-3">
              <button className="w-full flex items-center space-x-3 p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors">
                <Download className="h-5 w-5 text-gray-600" />
                <span className="text-gray-900 font-medium">Download Tickets & Vouchers</span>
              </button>
              <button className="w-full flex items-center space-x-3 p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors">
                <Calendar className="h-5 w-5 text-gray-600" />
                <span className="text-gray-900 font-medium">Add to Calendar</span>
              </button>
              <button className="w-full flex items-center space-x-3 p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors">
                <FileText className="h-5 w-5 text-gray-600" />
                <span className="text-gray-900 font-medium">View Invoice</span>
              </button>
              <button className="w-full flex items-center space-x-3 p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors">
                <Shield className="h-5 w-5 text-gray-600" />
                <span className="text-gray-900 font-medium">Travel Insurance</span>
              </button>
            </div>
          </div>

          {/* Support & Contact */}
          <div className="bg-white rounded-xl shadow-sm border p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Need Help?</h3>
            <div className="space-y-4">
              <div className="p-4 bg-blue-50 rounded-lg">
                <div className="flex items-center space-x-3 mb-2">
                  <MessageCircle className="h-5 w-5 text-blue-600" />
                  <span className="font-medium text-blue-900">24/7 Support</span>
                </div>
                <p className="text-sm text-blue-700 mb-3">
                  Our travel experts are available around the clock to assist you.
                </p>
                <button className="bg-blue-600 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-blue-700 transition-colors">
                  Contact Support
                </button>
              </div>

              <div className="space-y-2">
                <div className="flex items-center justify-between text-sm">
                  <span className="text-gray-600">Emergency Hotline</span>
                  <span className="font-medium text-gray-900">+1 (800) 123-4567</span>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span className="text-gray-600">Email Support</span>
                  <span className="font-medium text-gray-900">help@tourgenie.com</span>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span className="text-gray-600">Live Chat</span>
                  <span className="font-medium text-blue-600 cursor-pointer hover:text-blue-700">Start Chat</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Payment Information */}
        <div className="bg-white rounded-xl shadow-sm border p-6 mt-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Payment Information</h3>
          <div className="grid md:grid-cols-2 gap-6">
            <div>
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-gray-600">Hotel (2 nights)</span>
                  <span className="font-medium text-gray-900">€{bookingData.hotel.totalPrice}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-gray-600">Train (2 passengers)</span>
                  <span className="font-medium text-gray-900">€{bookingData.transport.totalPrice}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-gray-600">Flight (2 passengers)</span>
                  <span className="font-medium text-gray-900">€{bookingData.flight.totalPrice}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-gray-600">Service Fee</span>
                  <span className="font-medium text-gray-900">€12</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-gray-600">Taxes</span>
                  <span className="font-medium text-gray-900">€29</span>
                </div>
                <div className="border-t border-gray-200 pt-3">
                  <div className="flex items-center justify-between">
                    <span className="text-lg font-semibold text-gray-900">Total Paid</span>
                    <span className="text-lg font-bold text-gray-900">€{bookingData.totalAmount}</span>
                  </div>
                </div>
              </div>
            </div>
            <div>
              <div className="p-4 bg-gray-50 rounded-lg">
                <div className="flex items-center space-x-3 mb-3">
                  <CreditCard className="h-5 w-5 text-gray-600" />
                  <span className="font-medium text-gray-900">Payment Method</span>
                </div>
                <div className="text-sm text-gray-600 mb-2">Visa ending in 4242</div>
                <div className="text-sm text-gray-600">Paid on {formatDate(bookingData.bookingDate)}</div>
                <div className="mt-3 pt-3 border-t border-gray-200">
                  <div className="flex items-center space-x-2 text-sm text-green-600">
                    <CheckCircle className="h-4 w-4" />
                    <span>Payment Confirmed</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Important Notes */}
        <div className="bg-yellow-50 border border-yellow-200 rounded-xl p-6 mt-6">
          <h3 className="text-lg font-semibold text-yellow-800 mb-3">Important Travel Information</h3>
          <div className="space-y-2 text-sm text-yellow-700">
            <p>• Please arrive at the hotel after 3:00 PM for check-in and at the train station 30 minutes before departure.</p>
            <p>• Valid ID or passport required for all bookings. International travelers may need additional documentation.</p>
            <p>• Flight check-in opens 24 hours before departure. Web check-in is recommended.</p>
            <p>• Free cancellation policies vary by booking. Check individual cancellation terms above.</p>
            <p>• For any changes or assistance, contact our 24/7 support team using the information provided.</p>
          </div>
        </div>
      </div>

      {/* Modals */}
      {activeModal === 'modify-hotel' && (
        <ModificationModal 
          type="hotel" 
          booking={bookingData.hotel} 
          onClose={() => setActiveModal(null)} 
        />
      )}
      {activeModal === 'modify-transport' && (
        <ModificationModal 
          type="transport" 
          booking={bookingData.transport} 
          onClose={() => setActiveModal(null)} 
        />
      )}
      {activeModal === 'modify-flight' && (
        <ModificationModal 
          type="flight" 
          booking={bookingData.flight} 
          onClose={() => setActiveModal(null)} 
        />
      )}
      {activeModal === 'cancel-hotel' && (
        <CancellationModal 
          type="hotel" 
          booking={bookingData.hotel} 
          onClose={() => setActiveModal(null)} 
        />
      )}
      {activeModal === 'cancel-transport' && (
        <CancellationModal 
          type="transport" 
          booking={bookingData.transport} 
          onClose={() => setActiveModal(null)} 
        />
      )}
      {activeModal === 'cancel-flight' && (
        <CancellationModal 
          type="flight" 
          booking={bookingData.flight} 
          onClose={() => setActiveModal(null)} 
        />
      )}

      {/* Footer */}
      <footer className="bg-white border-t mt-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="flex flex-col md:flex-row justify-between items-center space-y-6 md:space-y-0">
            <p className="text-gray-600 text-sm">© 2025 Tour Genie. All rights reserved.</p>
            <div className="flex space-x-4">
              <a href="#" className="text-sm text-gray-600 hover:text-blue-600">Privacy Policy</a>
              <a href="#" className="text-sm text-gray-600 hover:text-blue-600">Terms of Service</a>
              <a href="#" className="text-sm text-gray-600 hover:text-blue-600">Contact</a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default BookingDetailsPage;