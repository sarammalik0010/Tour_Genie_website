import React, { useState, useEffect } from 'react';
import axios from 'axios';

const Settings = () => {
  const [notifications, setNotifications] = useState({ email: false, sms: false });
  const [passwordData, setPasswordData] = useState({ current: '', new: '', confirm: '' });
  const [message, setMessage] = useState('');
  const [loading, setLoading] = useState(true);

  const token = localStorage.getItem('token');

  useEffect(() => {
    axios.get('http://localhost:3000/users/settings', {
      headers: { Authorization: `Bearer ${token}` }
    })
      .then(res => {
        setNotifications(res.data.notifications || {});
      })
      .catch(console.error)
      .finally(() => setLoading(false));
  }, []);

  const handleToggle = (type) => {
    setNotifications(prev => ({ ...prev, [type]: !prev[type] }));
  };

  const handleSave = async () => {
    try {
      await axios.put('http://localhost:3000/users/settings', { notifications }, {
        headers: { Authorization: `Bearer ${token}` }
      });
      setMessage('Preferences saved ✅');
    } catch {
      setMessage('Failed to save ❌');
    }
    setTimeout(() => setMessage(''), 3000);
  };

  const handlePasswordChange = async () => {
    const { current, new: newPass, confirm } = passwordData;
    if (newPass !== confirm) return setMessage('Passwords do not match ❌');

    try {
      await axios.post('http://localhost:3000/users/change-password', {
        current, new: newPass
      }, { headers: { Authorization: `Bearer ${token}` } });

      setMessage('Password updated ✅');
      setPasswordData({ current: '', new: '', confirm: '' });
    } catch {
      setMessage('Password update failed ❌');
    }

    setTimeout(() => setMessage(''), 3000);
  };


  return (
    <div className="min-h-screen bg-gray-100 py-12 px-4">
      <div className="max-w-xl mx-auto bg-white shadow-lg rounded-lg p-8 space-y-10 animate-fade-in">
        <h2 className="text-3xl font-bold text-blue-700 text-center">⚙️ App Settings</h2>

        {/* Notifications */}
        <section>
          <h3 className="text-lg font-semibold text-gray-800 mb-4">🔔 Notification Preferences</h3>
          {['email', 'sms'].map(type => (
            <label key={type} className="flex items-center mb-2 cursor-pointer hover:text-blue-600 transition">
              <input
                type="checkbox"
                checked={notifications[type]}
                onChange={() => handleToggle(type)}
                className="mr-2 accent-blue-600 focus:ring-blue-400"
              />
              {type.toUpperCase()} Alerts
            </label>
          ))}
          <button
            onClick={handleSave}
            className="mt-4 w-full bg-blue-600 text-white py-2 rounded-lg transition duration-300 hover:bg-blue-700 shadow hover:shadow-md"
          >
            💾 Save Preferences
          </button>
        </section>

        {/* Change Password */}
        <section>
          <h3 className="text-lg font-semibold text-gray-800 mb-4">🔑 Change Password</h3>
          {['current', 'new', 'confirm'].map((field, i) => (
            <input
              key={i}
              type="password"
              placeholder={
                field === 'current'
                  ? 'Current Password'
                  : field === 'new'
                  ? 'New Password'
                  : 'Confirm New Password'
              }
              value={passwordData[field]}
              onChange={(e) => setPasswordData({ ...passwordData, [field]: e.target.value })}
              className="w-full mb-3 p-3 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-400 focus:border-transparent transition"
            />
          ))}
          <button
            onClick={handlePasswordChange}
            className="w-full bg-green-600 text-white py-2 rounded-lg hover:bg-green-700 transition duration-300 shadow hover:shadow-md"
          >
            🔄 Update Password
          </button>
        </section>

        {message && (
          <p className="text-center text-blue-600 text-sm mt-4 animate-fade-in">{message}</p>
        )}
      </div>
    </div>
  );
};

export default Settings;
