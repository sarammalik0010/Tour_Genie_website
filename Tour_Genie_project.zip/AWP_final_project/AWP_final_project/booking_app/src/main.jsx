import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import App from './App.jsx';
import './index.css';
import { createBrowserRouter, RouterProvider } from 'react-router-dom';
import LandingPage from './components/Landingpage/LandingPage.jsx';
import LoginPage from './components/Loginpage/LoginPage.jsx';
import SignupPage from './components/Signuppage/SignupPage.jsx';
import Dashboard from './components/Dashboardpage/dashboard.jsx';
import SearchBooking from './components/SearchBookingPage/SearchBookingpage.jsx';
import BookingDetailsPage from './components/BookingDetailspage/BookingDetails.jsx';
import Itinerary from './components/ItineraryPage/Itinerary.jsx';
import Recommendations from './components/RecommendationPage/Recommendations.jsx';
import Settings from './components/SettingPage/Settings.jsx';
import Help from './components/Help/Help.jsx';
import UserProfile from './components/UserProfilePage/UserProfile.jsx';
import BudgetPlanner from './components/BudgetPlanner/BudgetPlanner.jsx';
const router = createBrowserRouter([
  {
    path: '/',
    element: <App/>,
    children: [
      {
        path: '/',
        element: <LandingPage/>
      },
      {
        path: 'login',
        element: <LoginPage/>
      },
      {
        path: 'Signup',
        element: <SignupPage/>
      },
     {
     path: 'Dashboard',
        element: <Dashboard/>
      },
       {
     path: 'SearchBooking',
        element: <SearchBooking/>
      },
       {
     path: 'BookingDetails',
        element: <BookingDetailsPage/>
      },
      {
  path: 'Itinerary',
  element: <Itinerary />
},
{
  path: 'Recommendations',
  element: <Recommendations />
},
{ path: 'settings', 
  element: <Settings /> },

{
  path:'help',
  element:<Help/>
},
{
  path:'userprofile',
  element:<UserProfile/>
},
{
  path:'budgetplanner',
  element:<BudgetPlanner/>
}

        ]
  }
]);
createRoot(document.getElementById('root')).render(
  <StrictMode>
    <RouterProvider router={router} />
  </StrictMode>
);