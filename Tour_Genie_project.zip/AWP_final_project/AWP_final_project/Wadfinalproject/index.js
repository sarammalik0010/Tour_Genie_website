const express = require('express');
const app = express();
const bodyParser = require('body-parser');
const mongoose = require('mongoose');
const cors = require('cors'); // Add this line

// Import routes
const userRoutes = require('./routes/userRoutes');
const bookingRoutes = require('./routes/bookingRoutes');

// MongoDB connection setup (db.js)
const db = require('./db');

app.use(cors()); // Add this line
// Import routes

app.use((req, res, next) => {
    console.log(`[${new Date().toLocaleString()}] Request to ${req.originalUrl}`);
    next();
});

app.use(bodyParser.json());

app.use('/users', userRoutes);
app.use('/booking', bookingRoutes);

const port =  3000;
app.listen(port, () => {
    console.log(`Server running on port ${port}`);
});
