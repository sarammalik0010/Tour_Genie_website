const express = require('express');
const router = express.Router();
const Booking = require('../models/bookingmodel');  
const { jwtAuthMiddleware } = require('../jwt'); 

router.post('/', jwtAuthMiddleware, async (req, res) => {
  const { date, service } = req.body;

  try {
    const booking = new Booking({ user: req.user.userId,  date, service
    });

    await booking.save();
    res.status(201).json({ message: 'Booking created successfully', booking });
  } catch (err) {
    res.status(500).json({ message: 'Error creating booking', error: err });
  }
});

router.get('/', jwtAuthMiddleware, async (req, res) => {
    if (req.user.role !== 'admin') {
      return res.status(403).json({ message: 'You are not authorized to view all bookings' });
    }
  
    try {
      const bookings = await Booking.find(); 
      res.status(200).json(bookings);
    } catch (err) {
      res.status(500).json({ message: 'Error retrieving bookings', error: err });
    }
  });
  
  router.get('/:id', jwtAuthMiddleware, async (req, res) => {
    const { id } = req.params;
  
    try {
      const booking = await Booking.findById(id); 
      if (!booking) {
        return res.status(404).json({ message: 'Booking not found' });
      }
  
      res.status(200).json(booking);
    } catch (err) {
      res.status(500).json({ message: 'Error retrieving booking', error: err });
    }
  });
  router.put('/:id', jwtAuthMiddleware, async (req, res) => {
    const { id } = req.params;
    const { date, service, status } = req.body;
  
    try {
      const updatedBooking = await Booking.findByIdAndUpdate(
        id, 
        { date, service, status }, 
        { new: true, runValidators: true } 
      );
  
      if (!updatedBooking) {
        return res.status(404).json({ message: 'Booking not found' });
      }
  
      res.status(200).json({ message: 'Booking updated successfully', booking: updatedBooking });
    } catch (error) {
      res.status(500).json({ message: 'Internal server error', error });
    }
  });
  

router.delete('/:id', jwtAuthMiddleware, async (req, res) => {
  const { id } = req.params;

  if (req.user.role !== 'admin') {
    return res.status(403).json({ message: 'You are not authorized to delete this booking' });
  }

  try {
    const booking = await Booking.findByIdAndDelete(id);
    if (!booking) {
      return res.status(404).json({ message: 'Booking not found' });
    }

    res.status(200).json({ message: 'Booking deleted successfully' });
  } catch (err) {
    res.status(500).json({ message: 'Error deleting booking', error: err });
  }
});

module.exports = router;
