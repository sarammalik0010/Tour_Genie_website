const express = require('express');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const User = require('../models/usermodel'); 
const router = express.Router();

const JWT_SECRET = '4151';


router.post('/register', async (req, res) => {
    try {
        console.log('Request Body:', req.body);
        const { email } = req.body;     
        const user = await User.findOne({ email });
        if (user) {
            return res.status(400).json({ message: 'User already exists' });
        }
        const newUser = new User(req.body); 
        await newUser.save();
        res.status(201).json({ message: 'User registered successfully' });
    } catch (error) {
        res.status(500).json({ message: 'Server error' , error: error.message });
    }
})

router.post('/login', async (req, res) => {
    try {
        const { email, password } = req.body;  
        const user = await User.findOne({ email });
  
        if (user) {
            const isMatch = await user.comparePassword(password);
            if (isMatch) { 
                const token = user.generateToken();
                return res.status(200).json({
                    message: 'Logged in successfully',
                    token,
                    user: {
                        name: user.name,
                    },
                });
            } else {
                return res.status(400).json({ message: 'Incorrect password' });
            }
        } else {
            return res.status(400).json({ message: 'User not found' });
        }

    } catch (error) {
        console.error('Error during login:', error);
        res.status(500).json({ message: error.message });
    }
});
  

router.get('/profile', async (req, res) => {
  try {
    const user = await User.findById(req.user.userId); 
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    res.status(200).json({ name: user.name, email: user.email, role: user.role, department: user.department });
  } catch (err) {
    res.status(500).json({ message: 'Error retrieving user profile', error: err });
  }
});

router.put('/:id', async (req, res) => {
    const { id } = req.params;
    const { name, password } = req.body;

    if (req.user.userId !== id && req.user.role !== 'admin') {
        return res.status(403).json({ message: 'You are not authorized to update this user' });
    }

    try {
        const updateData = {};
        if (name) updateData.name = name;
        if (password) {
            const salt = await bcrypt.genSalt(10);
            updateData.password = await bcrypt.hash(password, salt);
        }

        const user = await User.findByIdAndUpdate(id, updateData, {
            new: true,         
            runValidators: true
        });

        // If user is not found
        if (!user) {
            return res.status(404).json({ message: 'User not found' });
        }

        res.status(200).json({ message: 'User updated successfully', user });
    } catch (err) {
        res.status(500).json({ message: 'Error updating user', error: err });
    }
});

  
  

router.delete('/:id', async (req, res) => {
  const { id } = req.params;

  if (req.user.role !== 'admin') {
    return res.status(403).json({ message: 'You are not authorized to delete this user' });
  }

  try {
    const user = await User.findByIdAndDelete(id);
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    res.status(200).json({ message: 'User deleted successfully' });
  } catch (err) {
    res.status(500).json({ message: 'Error deleting user', error: err });
  }
});

module.exports = router;
