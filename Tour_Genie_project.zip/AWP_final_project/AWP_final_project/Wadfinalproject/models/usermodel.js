const mongoose = require('mongoose');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const UserSchema = new mongoose.Schema({
  name: { 
    type: String, 
    required: true, 
  },
  email: { 
    type: String, 
    unique: true, 
    required: true, 
  },
  password: { 
    type: String, 
    required: true, 
  },
  role: { 
    type: String, 
    enum: ["user", "admin"], 
    required: true, 
  },
  phone: {
    type: String, 
    trim: true, 
  },
  department: { 
    type: String, 
    trim: true, 
  },
}, { timestamps: true });
UserSchema.pre('save', async function(next) {
    if (this.isModified('password')) {
        const salt = await bcrypt.genSalt(10);
        this.password = await bcrypt.hash(this.password, salt);
    }
    next();
});

UserSchema.methods.comparePassword = async function (candidatePassword) {
    const isMatch = await bcrypt.compare(candidatePassword, this.password);
    console.log('Password comparison result:', isMatch);
    return isMatch;
};

UserSchema.methods.generateToken = function() {
    return jwt.sign(
        { id: this._id, name: this.name , role : this.role},
        "l1f22bsse0394" ,
        { expiresIn: '1h' }
    );
};

module.exports = mongoose.model('User', UserSchema);
